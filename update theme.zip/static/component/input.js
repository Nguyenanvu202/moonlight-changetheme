import { ComponentEvent } from "./index.js";

// Global registry for all open dropdowns
const openDropdowns = new Set();

// Global click handler to close all open dropdowns when clicking outside
let globalClickHandler = null;

function setupGlobalClickHandler() {
    if (globalClickHandler) return;
    
    globalClickHandler = (e) => {
        // Close all open dropdowns if click is outside any of them
        let clickedInsideAny = false;
        for (const component of openDropdowns) {
            if (component.wrapper.contains(e.target) || component.dropdown.contains(e.target)) {
                clickedInsideAny = true;
                break;
            }
        }
        
        if (!clickedInsideAny) {
            const componentsToClose = Array.from(openDropdowns);
            componentsToClose.forEach(component => {
                component.close();
            });
        }
    };
    
    // Use capture phase to catch events before stopPropagation
    document.addEventListener("click", globalClickHandler, true);
}

export class ElementWithLabel {
    constructor(internalName, displayName) {
        this.div = document.createElement("div");
        this.label = document.createElement("label");
        if (displayName) {
            this.label.htmlFor = internalName;
            this.label.innerText = displayName;
            this.div.appendChild(this.label);
        }
    }
    mount(parent) {
        parent.appendChild(this.div);
    }
    unmount(parent) {
        parent.removeChild(this.div);
    }
}

export class InputComponent extends ElementWithLabel {
    constructor(internalName, type, displayName, init) {
        super(internalName, displayName);
        this.fileLabel = null;
        this.input = document.createElement("input");
        this.div.classList.add("input-div");
        this.input.id = internalName;
        this.input.type = type;
        if ((init === null || init === void 0 ? void 0 : init.defaultValue) != null) {
            this.input.defaultValue = init.defaultValue;
        }
        if ((init === null || init === void 0 ? void 0 : init.value) != null) {
            this.input.value = init.value;
        }
        if (init && init.checked != null) {
            this.input.checked = init.checked;
        }
        if (init && init.step != null) {
            this.input.step = init.step;
        }
        if (init && init.accept != null) {
            this.input.accept = init.accept;
        }
        if (init && init.inputMode != null) {
            this.input.inputMode = init.inputMode;
        }
        if (type == "file") {
            this.fileLabel = document.createElement("div");
            this.fileLabel.innerText = this.label.innerText;
            this.fileLabel.classList.add("file-label");
            this.label.innerText = "Open File";
            this.label.classList.add("file-button");
            this.div.insertBefore(this.fileLabel, this.label);
        }
        this.div.appendChild(this.input);
        this.input.addEventListener("change", () => {
            this.div.dispatchEvent(new ComponentEvent("ml-change", this));
        });
    }
    reset() {
        this.input.value = "";
    }
    getValue() {
        return this.input.value;
    }
    isChecked() {
        return this.input.checked;
    }
    getFiles() {
        return this.input.files;
    }
    setEnabled(enabled) {
        this.input.disabled = !enabled;
    }
    addChangeListener(listener, options) {
        this.div.addEventListener("ml-change", listener, options);
    }
    removeChangeListener(listener) {
        this.div.removeEventListener("ml-change", listener);
    }
}

export class SelectComponent extends ElementWithLabel {
    constructor(internalName, options, init) {
        super(internalName, init?.displayName);
        // Store internalName for logic checks
        this.internalName = internalName;
        this.options = options;
        this.preSelectedOption = init?.preSelectedOption || "";
        this.isOpen = false;

        this.wrapper = document.createElement("div");
        this.wrapper.classList.add("custom-select");
        this.wrapper.tabIndex = 0;

        this.selectedDisplay = document.createElement("div");
        this.selectedDisplay.classList.add("custom-select__display");
        this.selectedDisplay.innerText = "";

        this.dropdown = document.createElement("ul");
        this.dropdown.classList.add("custom-select__dropdown");
        this.dropdown.style.display = "none";

        this.optionElements = [];
        for (const option of options) {
            const li = document.createElement("li");
            li.classList.add("custom-select__option");
            li.dataset.value = option.value;
            li.innerText = option.name;
            if (option.value === this.preSelectedOption) {
                this.setSelectedOption(option);
            }
            li.addEventListener("click", () => {
                this.setSelectedOption(option);
                this.close();
            });
            this.dropdown.appendChild(li);
            this.optionElements.push({ option, element: li });
        }

        if (!this.selectedValue) {
            this.selectedDisplay.innerText = init?.placeholder || "Select...";
            this.selectedValue = "";
        }

        this.wrapper.appendChild(this.selectedDisplay);
        this.wrapper.appendChild(this.dropdown);
        this.div.appendChild(this.wrapper);

        this.dropdown.addEventListener("click", (e) => {
            e.stopPropagation();
        });

        this.wrapper.addEventListener("click", (e) => {
            if (e.target === this.selectedDisplay || e.target === this.wrapper) {
                e.stopPropagation();
            }
            this.toggle();
        });

        this.wrapper.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                this.close();
            } else if (e.key === "ArrowDown" && !this.isOpen) {
                this.open();
            }
        });
    }

    selectedValue = "";
    selectedName = "";

    setSelectedOption(option) {
        this.selectedValue = option.value;
        this.selectedName = option.name;
        this.selectedDisplay.innerText = option.name;
        this.div.dispatchEvent(new ComponentEvent("ml-change", this));
    }

    toggle() {
        if (this.isOpen) {
            this.close();
        } else {
            this.open();
        }
    }

    open() {
        // Close other dropdowns
        const componentsToClose = Array.from(openDropdowns);
        componentsToClose.forEach(component => {
            if (component !== this) {
                component.close();
            }
        });

        // Detect sidebar position
        const sidebarRoot = document.getElementById("sidebar-root");
        const isSidebarDown = sidebarRoot?.classList.contains("sidebar-edge-down");
        const isMouseOrTouchMode = this.internalName === "mouseMode" || this.internalName === "touchMode";
        const shouldOpenUpwards = isSidebarDown && isMouseOrTouchMode;

        // Reset both top and bottom first
        this.dropdown.style.top = "";
        this.dropdown.style.bottom = "";

        if (shouldOpenUpwards) {
            this.wrapper.classList.add("dropdown-up");
            this.dropdown.style.top = "auto";
            this.dropdown.style.bottom = "calc(100% + 4px)";
        } else {
            this.wrapper.classList.remove("dropdown-up");
            this.dropdown.style.bottom = "auto";
            this.dropdown.style.top = "calc(100% + 4px)";
        }

        this.dropdown.style.display = "block";
        this.isOpen = true;
        this.wrapper.classList.add("open");
        openDropdowns.add(this);
        setupGlobalClickHandler();
    }

    close() {
        this.dropdown.style.display = "none";
        this.isOpen = false;
        this.wrapper.classList.remove("open");
        this.wrapper.classList.remove("dropdown-up");
        openDropdowns.delete(this);
    }

    getValue() {
        return this.selectedValue;
    }

    reset() {
        this.selectedValue = "";
        this.selectedName = "";
        this.selectedDisplay.innerText = "Select...";
    }

    setOptionEnabled(value, enabled) {
        for (const { option, element } of this.optionElements) {
            if (option.value === value) {
                if (enabled) {
                    element.classList.remove("disabled");
                    element.style.pointerEvents = "";
                } else {
                    element.classList.add("disabled");
                    element.style.pointerEvents = "none";
                }
                break;
            }
        }
    }

    addChangeListener(listener, options) {
        this.div.addEventListener("ml-change", listener, options);
    }

    removeChangeListener(listener) {
        this.div.removeEventListener("ml-change", listener);
    }
}

export function isElementSupported(tag) {
    const element = document.createElement(tag);
    if (tag.indexOf('-') > -1) {
        return (
            element.constructor !== window.HTMLUnknownElement &&
            element.constructor !== window.HTMLElement
        );
    }
    return Object.prototype.toString.call(element) !== '[object HTMLUnknownElement]';
}
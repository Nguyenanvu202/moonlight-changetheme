import { ComponentEvent } from "./index.js";
export class ElementWithLabel {
    constructor(internalName, displayName) {
        this.div = document.createElement("div");
        this.label = document.createElement("label");
        if (displayName) {
            this.label.htmlFor = internalName;
            this.label.innerText = displayName;
            this.div.appendChild(this.label);
        }
    }
    mount(parent) {
        parent.appendChild(this.div);
    }
    unmount(parent) {
        parent.removeChild(this.div);
    }
}
export class InputComponent extends ElementWithLabel {
    constructor(internalName, type, displayName, init) {
        super(internalName, displayName);
        this.fileLabel = null;
        this.input = document.createElement("input");
        this.div.classList.add("input-div");
        this.input.id = internalName;
        this.input.type = type;
        if ((init === null || init === void 0 ? void 0 : init.defaultValue) != null) {
            this.input.defaultValue = init.defaultValue;
        }
        if ((init === null || init === void 0 ? void 0 : init.value) != null) {
            this.input.value = init.value;
        }
        if (init && init.checked != null) {
            this.input.checked = init.checked;
        }
        if (init && init.step != null) {
            this.input.step = init.step;
        }
        if (init && init.accept != null) {
            this.input.accept = init.accept;
        }
        if (init && init.inputMode != null) {
            this.input.inputMode = init.inputMode;
        }
        if (type == "file") {
            this.fileLabel = document.createElement("div");
            this.fileLabel.innerText = this.label.innerText;
            this.fileLabel.classList.add("file-label");
            this.label.innerText = "Open File";
            this.label.classList.add("file-button");
            this.div.insertBefore(this.fileLabel, this.label);
        }
        this.div.appendChild(this.input);
        this.input.addEventListener("change", () => {
            this.div.dispatchEvent(new ComponentEvent("ml-change", this));
        });
    }
    reset() {
        this.input.value = "";
    }
    getValue() {
        return this.input.value;
    }
    isChecked() {
        return this.input.checked;
    }
    getFiles() {
        return this.input.files;
    }
    setEnabled(enabled) {
        this.input.disabled = !enabled;
    }
    addChangeListener(listener, options) {
        this.div.addEventListener("ml-change", listener, options);
    }
    removeChangeListener(listener) {
        this.div.removeEventListener("ml-change", listener);
    }
}
export class SelectComponent extends ElementWithLabel {
    constructor(internalName, options, init) {
        super(internalName, init?.displayName);
        this.options = options;
        this.preSelectedOption = init?.preSelectedOption || "";
        this.isOpen = false;

        // Container for the custom select
        this.wrapper = document.createElement("div");
        this.wrapper.classList.add("custom-select");
        this.wrapper.tabIndex = 0; // makes it focusable

        // Displayed value (acts like the select button)
        this.selectedDisplay = document.createElement("div");
        this.selectedDisplay.classList.add("custom-select__display");
        this.selectedDisplay.innerText = ""; // will be set below

        // Dropdown list container
        this.dropdown = document.createElement("ul");
        this.dropdown.classList.add("custom-select__dropdown");
        this.dropdown.style.display = "none"; // hidden by default

        // Build options
        this.optionElements = [];
        for (const option of options) {
            const li = document.createElement("li");
            li.classList.add("custom-select__option");
            li.dataset.value = option.value;
            li.innerText = option.name;
            if (option.value === this.preSelectedOption) {
                this.setSelectedOption(option);
            }
            li.addEventListener("click", () => {
                this.setSelectedOption(option);
                this.close();
            });
            this.dropdown.appendChild(li);
            this.optionElements.push({ option, element: li });
        }

        // If nothing pre-selected, show placeholder or first item
        if (!this.selectedValue) {
            this.selectedDisplay.innerText = init?.placeholder || "Select...";
            this.selectedValue = "";
        }

        this.wrapper.appendChild(this.selectedDisplay);
        this.wrapper.appendChild(this.dropdown);
        this.div.appendChild(this.wrapper);

        // Prevent clicks from going through dropdown
        this.dropdown.addEventListener("click", (e) => {
            e.stopPropagation();
        });

        // Toggle on click
        this.wrapper.addEventListener("click", (e) => {
            e.stopPropagation();
            this.toggle();
        });

        // Optional: close on ESC
        this.wrapper.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                this.close();
            } else if (e.key === "ArrowDown" && !this.isOpen) {
                this.open();
            }
        });
    }

    // Current state
    selectedValue = "";
    selectedName = "";

    setSelectedOption(option) {
        this.selectedValue = option.value;
        this.selectedName = option.name;
        this.selectedDisplay.innerText = option.name;
        this.div.dispatchEvent(new ComponentEvent("ml-change", this));
    }

    toggle() {
        if (this.isOpen) {
            this.close();
        } else {
            this.open();
        }
    }

    open() {
        this.dropdown.style.display = "block";
        this.isOpen = true;
        this.wrapper.classList.add("open");
        
        // Close dropdown when clicking outside
        this.clickOutsideHandler = (e) => {
            if (!this.wrapper.contains(e.target)) {
                this.close();
                document.removeEventListener("click", this.clickOutsideHandler);
            }
        };
        // Use setTimeout to avoid immediate closure
        setTimeout(() => {
            document.addEventListener("click", this.clickOutsideHandler);
        }, 0);
    }

    close() {
        this.dropdown.style.display = "none";
        this.isOpen = false;
        this.wrapper.classList.remove("open");
        
        // Remove click outside handler if it exists
        if (this.clickOutsideHandler) {
            document.removeEventListener("click", this.clickOutsideHandler);
            this.clickOutsideHandler = null;
        }
    }

    // --- Public API (matches your original interface) ---

    getValue() {
        return this.selectedValue;
    }

    reset() {
        this.selectedValue = "";
        this.selectedName = "";
        const placeholder = "Select..."; // or pass via init
        this.selectedDisplay.innerText = placeholder;
    }

    setOptionEnabled(value, enabled) {
        for (const { option, element } of this.optionElements) {
            if (option.value === value) {
                if (enabled) {
                    element.classList.remove("disabled");
                    element.style.pointerEvents = "";
                } else {
                    element.classList.add("disabled");
                    element.style.pointerEvents = "none";
                }
                break;
            }
        }
    }

    addChangeListener(listener, options) {
        this.div.addEventListener("ml-change", listener, options);
    }

    removeChangeListener(listener) {
        this.div.removeEventListener("ml-change", listener);
    }
}
export function isElementSupported(tag) {
    // Create a test element for the tag
    const element = document.createElement(tag);
    // Check for support of custom elements registered via
    // `document.registerElement`
    if (tag.indexOf('-') > -1) {
        // Registered elements have their own constructor, while unregistered
        // ones use the `HTMLElement` or `HTMLUnknownElement` (if invalid name)
        // constructor (http://stackoverflow.com/a/28210364/1070244)
        return (element.constructor !== window.HTMLUnknownElement &&
            element.constructor !== window.HTMLElement);
    }
    // Obtain the element's internal [[Class]] property, if it doesn't 
    // match the `HTMLUnknownElement` interface than it must be supported
    return toString.call(element) !== '[object HTMLUnknownElement]';
}
;
